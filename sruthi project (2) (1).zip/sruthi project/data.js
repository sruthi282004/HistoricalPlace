<!DOCTYPE html>
<html>
<body>

<h3>Registration completed</h3>

<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
Display Date and Time of completion.</button>

<p id="demo"></p>

</body>
</html> 
