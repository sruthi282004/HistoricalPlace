Historical-Places-To-Visit-In-India-Website
Technology: HTML, CSS, JavaScript, AJAX.
• Designed a website with brief historical information about the places of interest for the tourists, according to the various states in India. An inquiry page for interested users is also available